# © @AnonymousBoy1025

__mod_name__ = "Tᴏᴏʟs"

__help__ = """

*Converts*
 ❍ /encrypt*:* Encrypts The Given Text
 ❍ /decrypt*:* Decrypts Previously Ecrypted Text
"""
